import type { MealPlan, TrainingProgram, UserProfile } from "@/domain/types";

export type CoachContext = {
  profile: Pick<UserProfile, "name" | "goal" | "weightKg" | "daysPerWeek" | "injuries" | "medicalFlags">;
  program: Pick<TrainingProgram, "split" | "rationale">;
  nutrition: Pick<MealPlan["target"], "calories" | "proteinG" | "carbsG" | "fatG">;
};

export interface AIProvider {
  answer(question: string, context: CoachContext): Promise<string>;
}

export class MockAIProvider implements AIProvider {
  async answer(question: string, context: CoachContext): Promise<string> {
    const risk = context.profile.medicalFlags.length > 0 || context.profile.injuries.length > 0;
    if (risk && /درد|آسیب|بیماری|قلب|دیابت/.test(question)) {
      return "با توجه به موارد احتیاطی ثبت‌شده، من تشخیص پزشکی نمی‌دهم. شدت تمرین را محافظه‌کارانه نگه دار و برای شروع برنامه سنگین با پزشک یا فیزیوتراپیست مشورت کن.";
    }
    if (/پروتئین/.test(question)) {
      return `هدف پروتئین امروز شما ${context.nutrition.proteinG} گرم است. این مقدار بر اساس وزن بدن و هدف فعلی تنظیم شده است.`;
    }
    if (/امروز|تمرین/.test(question)) {
      return `برنامه فعلی شما ${context.program.split} است. دلیل انتخاب: ${context.program.rationale[0]}`;
    }
    if (/نرسم|باشگاه/.test(question)) {
      return "اگر امروز به باشگاه نرسیدی، جلسه را به نزدیک‌ترین روز آزاد منتقل کن. برنامه را کامل از نو نساز؛ فقط ترتیب هفته را جابه‌جا کن.";
    }
    return "پیشنهاد من بر اساس پروفایل، برنامه تمرین و هدف تغذیه فعلی توست: امروز روی اجرای ساده برنامه، ثبت وعده‌ها و خواب کافی تمرکز کن.";
  }
}
