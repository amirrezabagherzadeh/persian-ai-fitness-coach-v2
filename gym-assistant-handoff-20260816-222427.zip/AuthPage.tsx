"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Dumbbell } from "lucide-react";
import { useAppStore } from "@/store/app-store";

export function AuthPage({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const { state, setUser } = useAppStore();
  const [name, setName] = useState(state.user.name);
  const [email, setEmail] = useState(state.user.email);
  return (
    <main className="hero">
      <div className="hero-inner" style={{ display: "grid", placeItems: "center" }}>
        <form
          className="light-panel"
          style={{ width: "min(480px, 100%)" }}
          onSubmit={(event) => {
            event.preventDefault();
            setUser({ ...state.user, name: name || "کاربر", email, role: email.includes("admin") ? "admin" : state.user.role });
            router.push(mode === "signup" ? "/onboarding" : "/dashboard");
          }}
        >
          <div className="brand" style={{ color: "var(--ink)", marginBottom: 24 }}>
            <span className="brand-mark"><Dumbbell size={20} /></span>
            <span>Gym Coach</span>
          </div>
          <h1 style={{ fontSize: 32 }}>{mode === "signup" ? "ساخت حساب" : "ورود"}</h1>
          <p className="muted-dark">در نسخه MVP احراز هویت به صورت محلی شبیه‌سازی شده و برای Supabase آماده است.</p>
          {mode === "signup" ? (
            <div className="field">
              <label htmlFor="name">نام</label>
              <input className="input" id="name" value={name} onChange={(event) => setName(event.target.value)} />
            </div>
          ) : null}
          <div className="field" style={{ marginTop: 12 }}>
            <label htmlFor="email">ایمیل</label>
            <input className="input ltr" id="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </div>
          <div className="field" style={{ marginTop: 12 }}>
            <label htmlFor="password">رمز عبور</label>
            <input className="input ltr" id="password" type="password" minLength={6} defaultValue="demo1234" required />
          </div>
          <button className="btn dark" style={{ width: "100%", marginTop: 18 }} type="submit">
            {mode === "signup" ? "ادامه به ارزیابی" : "ورود به داشبورد"}
          </button>
          <p className="muted-dark" style={{ margin: "14px 0 0" }}>
            {mode === "signup" ? "حساب داری؟ " : "حساب نداری؟ "}
            <Link href={mode === "signup" ? "/auth/login" : "/auth/signup"}>{mode === "signup" ? "وارد شو" : "ثبت‌نام کن"}</Link>
          </p>
        </form>
      </div>
    </main>
  );
}
