Place licensed Kalameh webfont files here if you want browser-loaded Kalameh.

Expected names:
- Kalameh-Regular.woff2
- Kalameh-Medium.woff2
- Kalameh-SemiBold.woff2
- Kalameh-Bold.woff2
- Kalameh-ExtraBold.woff2

The provided zip was AES-encrypted and could not be extracted without its password.
