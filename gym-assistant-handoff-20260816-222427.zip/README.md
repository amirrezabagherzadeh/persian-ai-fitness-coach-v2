# Persian AI Fitness & Nutrition Coach

Persian-first, mobile-focused MVP for personalized resistance training, nutrition planning, workout logging, food logging, progress tracking, reminders, admin knowledge management, and an AI coach abstraction.

## Local Setup

```bash
npm install
npm run dev
```

Open `http://localhost:3000`. Use the demo directly or create a local account through `/auth/signup`.

## What Works

- Landing, signup/login mock, and multi-step onboarding
- Deterministic training program generation
- Deterministic calorie and macro targets
- Real meal plan from structured food data
- Active workout mode with set logging and rest timer
- Food logging with live macro totals
- Reminders and browser notification architecture
- Weekly check-in and readiness-based adaptation
- Progress charts
- AI coach provider abstraction with safe mock responses
- Admin route for exercises, foods, knowledge, and rules
- Coach methodology ingestion with optional AI review, approve/activate, and program regeneration by coach style
- PWA manifest and service worker shell

## Environment

Copy `.env.example` to `.env.local` when wiring real services.

```bash
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
AI_PROVIDER=mock
AI_API_KEY=
```

Never expose service role or AI keys to the browser.

## Database

The normalized PostgreSQL/Supabase schema is in `supabase/migrations/20260815000000_initial_schema.sql`.

Supabase CLI was not installed in this workspace, so before applying to a real project:

```bash
supabase db reset
supabase db advisors
supabase migration list --local
```

Current Supabase changelog context checked during implementation: new public tables may not be automatically exposed to the Data API, and extension version pinning is deprecated. This schema enables RLS on public tables and uses owner predicates for sensitive user rows.

## Recommendation Logic

See `docs/product-logic.md`. Core calculations live under `src/domain` and are covered by tests. AI is used only for explanations and coaching language.

## Handoff

For transferring this project to another developer, see `HANDOFF.md`.

## Current Limitations

- Auth and persistence are local/demo implementations.
- Seed nutrition and exercise values are demo data unless explicitly verified.
- Admin editing UI is scaffolded for management workflows but does not yet write to a server database.
- Browser notifications require permission and are not native push yet.
