import { CheckInPage } from "@/features/checkin/CheckInPage";

export default function CheckInRoute() {
  return <CheckInPage />;
}
