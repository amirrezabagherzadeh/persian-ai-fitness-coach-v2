import { WorkoutDayPage } from "@/features/program/WorkoutDayPage";

export default async function WorkoutDayRoute({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <WorkoutDayPage id={id} />;
}
