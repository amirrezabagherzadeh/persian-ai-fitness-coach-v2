import { nf, percent } from "@/lib/format";

export function MacroProgress({ label, current, target, unit = "g" }: { label: string; current: number; target: number; unit?: string }) {
  const ratio = target > 0 ? Math.min(100, (current / target) * 100) : 0;
  return (
    <div className="grid" style={{ gap: 8 }}>
      <div className="split">
        <strong>{label}</strong>
        <span className="muted-dark">{nf(current)} / {nf(target)} {unit}</span>
      </div>
      <div className="macro-bar"><span style={{ width: `${ratio}%` }} /></div>
      <small className="muted-dark">{percent(ratio)} تکمیل شده</small>
    </div>
  );
}
