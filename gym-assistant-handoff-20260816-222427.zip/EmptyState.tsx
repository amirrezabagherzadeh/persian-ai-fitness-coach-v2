export function EmptyState({ title, action }: { title: string; action?: React.ReactNode }) {
  return (
    <div className="panel" style={{ textAlign: "center", padding: 28 }}>
      <p className="muted">{title}</p>
      {action}
    </div>
  );
}
