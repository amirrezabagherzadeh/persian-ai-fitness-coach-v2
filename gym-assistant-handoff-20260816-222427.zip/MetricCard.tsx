export function MetricCard({ label, value, helper }: { label: string; value: string; helper?: string }) {
  return (
    <div className="metric-card">
      <div className="muted">{label}</div>
      <div className="metric-value">{value}</div>
      {helper ? <div className="muted">{helper}</div> : null}
    </div>
  );
}
