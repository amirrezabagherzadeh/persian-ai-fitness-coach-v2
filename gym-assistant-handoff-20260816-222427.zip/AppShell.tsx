"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Activity, Dumbbell, LineChart, Salad, User, Shield, Bell, Bot } from "lucide-react";
import { fa } from "@/lib/i18n";

const mainLinks = [
  { href: "/dashboard", label: fa.nav.today, icon: Activity },
  { href: "/program", label: fa.nav.program, icon: Dumbbell },
  { href: "/nutrition", label: fa.nav.nutrition, icon: Salad },
  { href: "/progress", label: fa.nav.progress, icon: LineChart },
  { href: "/profile", label: fa.nav.profile, icon: User },
];

const secondaryLinks = [
  { href: "/reminders", label: "یادآورها", icon: Bell },
  { href: "/coach", label: "مربی AI", icon: Bot },
  { href: "/admin", label: "ادمین", icon: Shield },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);
  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="ناوبری اصلی">
        <Link className="brand" href="/dashboard">
          <span className="brand-mark"><Dumbbell size={20} /></span>
          <span>Gym Coach</span>
        </Link>
        <nav className="nav">
          {[...mainLinks, ...secondaryLinks].map((link) => {
            const Icon = link.icon;
            return (
              <Link key={link.href} className={`nav-link ${isActive(link.href) ? "active" : ""}`} href={link.href}>
                <Icon size={19} />
                <span>{link.label}</span>
              </Link>
            );
          })}
        </nav>
      </aside>
      <main className="main">{children}</main>
      <nav className="mobile-nav" aria-label="ناوبری موبایل">
        {mainLinks.map((link) => {
          const Icon = link.icon;
          return (
            <Link key={link.href} href={link.href} className={isActive(link.href) ? "active" : ""}>
              <Icon />
              <span>{link.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
